package com.chess.chessapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChessAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChessAppApplication.class, args);
	}

}
